<?php 

// DB Name = healthcheck

//$error = "error";

//$con = mysqli_connect('localhost','root','') or die($error);
//mysqli_select_db($con,'healthcheck') or die($error);

//$con = mysqli_connect("localhost","root","","healthcheck");


$con = mysqli_connect("localhost:3306","fulfilme_root","contributeajo123","fulfilme_healthcheck");

?>