<?php 

$msg = "";
session_start();
	include('inc/healthcheck.php');
	
   function redirect() {
       header('login.php');
       exit();
   }
   
   if(!isset($_GET['username']) || !isset($_GET['vkey'])){
       redirect();
   } else {
       $username = mysqli_real_escape_string($con,$_GET['username']);
       $vkey = $con->real_escape_string($_GET['vkey']);
       
       $sql = $con->query("SELECT id from users WHERE username = '$username' AND vkey = '$vkey' AND verified = 0");
       
       if ($sql->num_rows <= 0){
           redirect();
           $msg ="Something is wrong";
       } else {
           $con->query("UPDATE users SET verified = 1, vkey = '' WHERE username = '$username'");
           $msg = "Your email has been verified... You can login now!";
          
       }
   }
   
   

	
?>



<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | Verify</title>
		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
			crossorigin="anonymous">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
			crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
		
			
	</style>
	
</head>
<body>
    
    <header id="main-header">
		<h1>Lago Lindo Day Care</h1>
	</header>
	
	<hr>
	<br>
	<br>
    
        <div class="container" align='center'>
            <h4><?php echo $msg; ?></h4>
			<!-- <h4>Your email has been verified... You can now log in!</h4> -->
		</div>
		
		<br><br>
		
		<div class="container" align='center'>
			<a href='https://fulfilmentpriority.com/HealthCheck'>Click here to log in</a>
		</div>
		
		<br><br>

	<div class="container" align="left">
    	<div class="card card-container">
    		<form action="verify.php" method="get" >
            
    			
    		</form>
    	</div>
    </div>		
	
		


	<br> 
<br>

	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>


	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	

</body>
</html> 
	