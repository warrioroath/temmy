<?php 

/* session_start();
	include('inc/healthcheck.php'); */
?>

<!DOCTYPE html>

<html>
<head>
		<title>LagoLindo | Thank You</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<!-- Comment here -->
		<link rel="stylesheet" href="css/style.css" media="all"/>
		
		<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
	</style>
	

</head>

<body>

	<header id="main-header">
		<h1>Lago Lindo Day Care</h1>
	</header>


<hr>


		<div class="container" align='center'>
			<h4>Thank you for registering... An email has been sent to your email address for verification!</h4>
		</div>

	
	
	<br>
	<hr>
	
	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	
	
</body>
</html>


