<?php

$var = 'ayobami';
echo md5(uniqid($var, true));
echo "<br>";
echo substr(md5(uniqid($var, true)),0,6);
echo "<br>";
echo strtoupper(substr(md5(uniqid($var, true)),0,8));
echo "<br>";


echo "<br>";
echo substr(md5(time()), 0, 6);
echo "<br>"; 
echo "<br>";

echo rand(100,999);  // 3 random numbers between 100 and 999
echo "<br>";
echo mt_rand(100,999); 
echo "<br>";


$var = 'oluwa';

echo md5($var); 
echo "<br>";
echo sha1($var);
echo "<br>";
echo crypt($var); 
echo "<br>";
echo base64_encode($var);
