<?php  

session_start();

include('inc/healthcheck.php');

if(!$_SESSION['username']){
	header("location: login.php");
}
else{

?>

<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | Health Checks</title>
	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
		crossorigin="anonymous">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
		crossorigin="anonymous">
	  <link rel="stylesheet" href="css/style.css">
	  
	  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
			
	</style>
	
</head>
<body>




<?php 

// define variables and initialize with empty values
$individualname = $fever = $cough = $shortness = $sore = $chills = "";
//$indvErr = $fvrErr = $cghErr = $shtbrErr = $srtErr = $chlErr = "";
$errors = array('individualname' => '', 'fever' => '', 'cough' => '', 'shortness' => '', 'sore' => '', 'chills' => '');
	
	
	if(isset($_POST['submit'])){
		
		//getting the text information and saving in local variables
			$username = mysqli_real_escape_string($con,$_SESSION['username']);
			$todays = mysqli_real_escape_string($con,$_POST['todays']);
			

		if(isset($_POST['individualname'])){
			$individualname = mysqli_real_escape_string($con,$_POST['individualname']);
		}

		
		if(isset($_POST['fever'])){
			$fever = mysqli_real_escape_string($con,$_POST['fever']);
		}
		if(isset($_POST['cough'])){
			$cough = mysqli_real_escape_string($con,$_POST['cough']);
		}
		if(isset($_POST['shortness'])){
			$shortness = mysqli_real_escape_string($con,$_POST['shortness']);
		}
		if(isset($_POST['sore'])){
			$sore = mysqli_real_escape_string($con,$_POST['sore']);
		}
		if(isset($_POST['chills'])){
			$chills = mysqli_real_escape_string($con,$_POST['chills']);
		}
		
		
		//Individual's name must be supplied
		if(empty($_POST['individualname'])){
			$errors['individualname'] = 'Please fill in the individual\'s name!';
		}
		
		//An option must be selected
		if(empty($_POST['fever'])){
			$errors['fever'] = 'You must answer the question on Fever';
		}
		if(empty($_POST['cough'])){
			$errors['cough'] = 'You must answer the question on Cough';
		}
		if(empty($_POST['shortness'])){
			$errors['shortness'] = 'You must answer the question on Shortness of Breath';
		}
		if(empty($_POST['sore'])){
			$errors['sore'] = 'You must answer the question on Sore';
		}
		if(empty($_POST['chills'])){
			$errors['chills'] = 'You must answer the question on Chills';
		}
		
		//Check for errors on the form...
		if(array_filter($errors)){
			echo 'There are errors in your form';
		} else{	
			$insert = "insert into checks (username,individualname,todaydate,fever,cough,shortness,sore,chills,checkdate) values ('$username','$individualname','$todays','$fever','$cough','$shortness','$sore','$chills',NOW())";
			
			$run_insert = mysqli_query($con,$insert);
			
			if($run_insert){				
				//Taking these SESSIONs to the next page (thankyou.php)
				$_SESSION['individualname']=$individualname;
				$_SESSION['todays']=$todays;
				
				$id = mysqli_insert_id($con);
				$_SESSION['id'] = $id;
				$_SESSION['checkdate'] = $checkdate;
								
				echo "<script>window.open('thankyou.php','_self')</script>";
			}
		}
	
	} // end POST check
	
	
	
?>










	
		
	<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="index.php" class="navbar-brand">Home</a>
	  <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2">
            <a href="index.php" class="nav-link active">Health Check Form [Children]</a>
          </li>
          <li class="nav-item px-2">
            <a href="index.php" class="nav-link">Health Check Form [Adults 18+]</a>
          </li>
		  <li class="nav-item px-2">
            <a href="profile.php" class="nav-link">Profile</a>
          </li>
        </ul>

        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown mr-3">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
              <i class="fas fa-user"></i> Welcome: <strong><?php echo $_SESSION['username']; ?></strong> 
            </a>
            <div class="dropdown-menu">
              <a href="profile.php" class="dropdown-item">
                <i class="fas fa-user-circle"></i> Profile
              </a>
              <a href="newpassword.php" class="dropdown-item">
                <i class="fas fa-cog"></i> Password Change
              </a>
            </div>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">
              <i class="fas fa-user-times"></i> Logout
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
		
	
	<!-- HEADER -->
  <header id="main-header" class="py-2 bg-black text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>
            <i class="fas fa-notes-medical"></i> COVID-19 Health Check</h2>
        </div>
      </div>
    </div>
  </header>
  

<br> 

		<div class="container">	
			<h4>Overview</h4>
			<p>This checklist applies for all children, as well as all students who attend kindergarten to Grade 12, including high school students over 18. Children should be screened every day by completing this checklist before going to school, child care or other activities. Children may need a parent or guardian to assist them to complete this screening tool.</p>
		</div>


					
<div class="container" align="left">
	<div class="card card-container">
		<form action="index.php" method="post" >

			<div class="form-row">
                <div class="col">
					<strong>Individual's Name:</strong>
					<input type="text" name="individualname" placeholder="Enter Individual's Name" value="<?php echo htmlspecialchars($individualname)?>">
                </div>
				<div style="color:Red;"><?php echo $errors['individualname'];?></div>
				
                <div class="col">
					<strong for="today">Today's Date:</strong>
                    <input type="date" id="todays" name="todays">
                </div>
            </div>


			<!-- <label for="today">Today's Date:</label>
			<input type="date" id="todays" name="todays">
			
			<input type="hidden" id="id" name="id">
			<input type="hidden" id="checkdate" name="checkdate"> -->

			<br>


			<table>
				<tbody>
					<label>Does the attendee have any new onset (or worsening) of any of the following symptoms:</label>
					
					<tr>
						<td align="left"><span>Fever:</span></td>
						<td>
							<input type="radio" name="fever" <?php if (isset($_POST['fever']) && $_POST['fever']=="Yes") echo "checked";?> value="Yes"/>Yes
							<input type="radio" name="fever" <?php if (isset($_POST['fever']) && $_POST['fever']=="No") echo "checked";?> value="No"/>No
							<div style="color:Red;"><?php echo $errors['fever'];?></div>
						</td>
					</tr>
			
					<tr>
						<td align="left"><span>Cough:</span></td>
						<td>
							<input type="radio" name="cough" <?php if (isset($_POST['cough']) && $_POST['cough']=="Yes") echo "checked";?> value="Yes"/>Yes
							<input type="radio" name="cough" <?php if (isset($_POST['cough']) && $_POST['cough']=="No") echo "checked";?> value="No"/>No
							<div style="color:Red;"><?php echo $errors['cough'];?></div>
						</td>
					</tr>			
					
					<tr>
						<td align="left"><span>Shortness of Breath / Difficulty Breathing:</span></td>
						<td>
							<input type="radio" name="shortness" <?php if (isset($_POST['shortness']) && $_POST['shortness']=="Yes") echo "checked";?> value="Yes"/>Yes
							<input type="radio" name="shortness" <?php if (isset($_POST['shortness']) && $_POST['shortness']=="No") echo "checked";?> value="No"/>No
							<div style="color:Red;"><?php echo $errors['shortness'];?></div>
						</td>
					</tr>
			
					<tr>
						<td align="left"><span>Sore Throat:</span></td>
						<td>
							<input type="radio" name="sore" <?php if (isset($_POST['sore']) && $_POST['sore']=="Yes") echo "checked";?> value="Yes"/>Yes
							<input type="radio" name="sore" <?php if (isset($_POST['sore']) && $_POST['sore']=="No") echo "checked";?> value="No"/>No
							<div style="color:Red;"><?php echo $errors['sore'];?></div>
						</td>
					</tr>
					
					<tr>
						<td align="left"><span>Chills:</span></td>
						<td>
							<input type="radio" name="chills" <?php if (isset($_POST['chills']) && $_POST['chills']=="Yes") echo "checked";?> value="Yes"/>Yes
							<input type="radio" name="chills" <?php if (isset($_POST['chills']) && $_POST['chills']=="No") echo "checked";?> value="No"/>No
							<div style="color:Red;"><?php echo $errors['chills'];?></div>
						</td>
					</tr>
					
					
				</tbody>
			</table>

<!--	..................................................................................................		-->
		<br>
		
					<button class="btn btn-lg btn-primary btn-block btn-signin" style="width:120px; height:45px" name="submit" type="submit">Submit</button>
				

				</form>
			</div>
		</div>
		
		<br>
		
		<br>

		
<!--	..................................................................................................		-->
 		



	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
  
  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>


	<script language="javascript">
		document.getElementById('todays').value = "<?php echo date("Y-m-d"); ?>";
	</script>
	
	

		
	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	
</body>
</html>


<?php } ?>
