<?php 
session_start();

	include('inc/healthcheck.php');


?>


<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | OTP Reset</title>
		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
			crossorigin="anonymous">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
			crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
		
			
	</style>
	
</head>
<body>


<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="login.php" class="navbar-brand">Log In</a>
	  <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2">
            <a href="createuser.php" class="nav-link active">Create New Account</a>
          </li>
          <li class="nav-item px-2">
            <a href="passwordreset.php" class="nav-link">Reset Your Password</a>
          </li>
		</ul>
      </div>
    </div>
  </nav>
		
	
	<!-- HEADER -->
  <header id="main-header" class="py-2 bg-black text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h3>
            <i class="fas fa-unlock-alt"></i> OTP Reset Code</h3>
        </div>
      </div>
    </div>
  </header>

<br>
<br>

		

<div class="container" align="left">
	<div class="card card-container">
		<form action="otpreset.php" method="post" >

			<div class="form-row">
                <div class="col">
					<label><strong>OTP Code:</strong></label> <br>
					<input type="text" name="otpcode" placeholder="Enter the OTP Code"/>
                </div>
                
            </div>
			<br>			
			<button class="btn btn-lg btn-primary btn-block btn-signin"  name="submit" type="submit">Submit</button>
		</form>
	</div>
 </div>	




	<?php
	
    	if(isset($_POST['submit'])){
    	    
    	    $otpcode = mysqli_real_escape_string($con,$_POST['otpcode']); 
    	    
    	    if($otpcode==''){
    			echo "<script>alert('Please type in your OTP code!')</script>";
    			exit();
    		}
    	    
    	    
    	        $email = $_SESSION['email'];
    	        
    	        //$sel_user_id = "SELECT id FROM users WHERE email regexp '$email'";
    	        $sel_user_id = "SELECT userid FROM otptable a, users b WHERE a.id = b.id AND b.email regexp '$email'";
        		$run_user_id = mysqli_query($con,$sel_user_id);
        		
            		$rowuserid = mysqli_fetch_array($run_user_id);
            		$vuserid = '';
            		if($rowuserid){
            		    $vuserid = $rowuserid['userid']; // i.e. the value of userid Column in otptable Table
            		}
            		
        		echo $vuserid; 
        		echo "<br>";
        		printf($otpcode);
        		echo "<br>";
        		
        		//$sel_otp = "SELECT id FROM otptable WHERE userid = $vuserid AND otpcode = '$otpcode' AND otpstatus = 0";
        		//$sel_otp = "SELECT otpcode FROM otptable WHERE userid = $vuserid AND otpstatus = 0";
        		$sel_otp = "SELECT id FROM otptable WHERE userid = $vuserid AND otpcode = '$otpcode' AND otpstatus = 0";
        		$run_otp = mysqli_query($con,$sel_otp);
        		$check_otp = mysqli_num_rows($run_otp);
        		
        		echo "<br>";
        		printf($sel_otp);
        		echo "<br>";
        		printf($check_otp);
        		
        		if($check_otp==0){
        			echo "<script>alert('This OTP Code does not exist!')</script>";
        			exit();
        		}
        		
    			//$update = "UPDATE users SET otpstatus = 1, otpcode = '' WHERE email regexp '$email'";
    			$update = "UPDATE otptable SET otpcode = '', otpstatus = 1 WHERE userid = $vuserid";
    			
    			$run_update = mysqli_query($con,$update);
    			
    			if($run_update){
    			   echo "<script>alert('OTP code successfully verified!')</script>"; 
    			   echo "<script>window.open('newpassword.php','_self')</script>";
    			}
    	  
        } 
	
	?>


	<br> 
<br>

	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>


	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	

</body>
</html> 

