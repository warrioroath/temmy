<?php 

session_start();
	include('inc/healthcheck.php');

	if(!$_SESSION['username']){
		header("location: login.php");
	} 
	
?>


<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | Daily Check</title>
		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
			crossorigin="anonymous">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
			crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
		
			
	</style>
	
</head>
<body>


<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="index.php" class="navbar-brand">Home</a>
	  <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2">
            <a href="index.php" class="nav-link active">Health Check Form [Children]</a>
          </li>
          <li class="nav-item px-2">
            <a href="index.php" class="nav-link">Health Check Form [Adults 18+]</a>
          </li>
		  <li class="nav-item px-2">
            <a href="profile.php" class="nav-link">Profile</a>
          </li>
        </ul>

        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown mr-3">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
              <i class="fas fa-user"></i> Welcome: <strong><?php echo $_SESSION['username']; ?></strong> 
            </a>
            <div class="dropdown-menu">
              <a href="profile.php" class="dropdown-item">
                <i class="fas fa-user-circle"></i> Profile
              </a>
              <a href="settings.html" class="dropdown-item">
                <i class="fas fa-cog"></i> Settings
              </a>
            </div>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">
              <i class="fas fa-user-times"></i> Logout
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
		
	
	<!-- HEADER -->
  <header id="main-header" class="py-2 bg-black text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>
            <i class="fas fa-notes-medical"></i> COVID-19 Health Check</h2>
        </div>
      </div>
    </div>
  </header>

<br>
		
		
			
					
		<div class="container">
				<table class="table table-striped">
					<thead class="thead-dark">
						<tr>
							<th>Question</th>
							<th>Response</th>
						</tr>
					</thead>
					
						<?php  	
								
							$id = $_GET['id'];
							
							/* if(isset($_GET['id'])){
								$id = $_GET['id'];
							} */
														
							$sql1 = "select fever from checks where id = '$id'";
							$sql2 = "select cough from checks where id = '$id'";
							$sql3 = "select shortness from checks where id = '$id'";
							$sql4 = "select sore from checks where id = '$id'";
							$sql5 = "select chills from checks where id = '$id'";
							
							$sql6 = "select checkdate from checks where id = '$id'";
							$sql7 = "select individualname from checks where id = '$id'";
							
							
							$res1 = mysqli_query($con,$sql1);
							$res2 = mysqli_query($con,$sql2);
							$res3 = mysqli_query($con,$sql3);
							$res4 = mysqli_query($con,$sql4);
							$res5 = mysqli_query($con,$sql5);
							
							$res6 = mysqli_query($con,$sql6);
							$res7 = mysqli_query($con,$sql7);
							

							$row1 = mysqli_fetch_array($res1);
							$row2 = mysqli_fetch_array($res2);
							$row3 = mysqli_fetch_array($res3);
							$row4 = mysqli_fetch_array($res4);
							$row5 = mysqli_fetch_array($res5);
							
							$row6 = mysqli_fetch_array($res6);
							$row7 = mysqli_fetch_array($res7);
							
							
							$fv = '';
							$cg = '';
							$sh = '';
							$sr = '';
							$ch = '';
							
							$dt = '';
							$in = '';
							
							
							
							if($row1 || $row2){
							$fv = $row1['fever']; $cg = $row2['cough'];
							}
							/* if($row1){
							$fv = $row1['fever'];
							}
							if($row2){
							$cg = $row2['cough'];
							} */
							if($row3){
							$sh = $row3['shortness'];
							}
							if($row4){
							$sr = $row4['sore'];
							}
							if($row5){
							$ch = $row5['chills'];
							}
							
							if($row6){
							$dt = $row6['checkdate'];
							}
							if($row7){
							$in = $row7['individualname'];
							}
														
													
						?>
						
						
					
						<h5>Result of Responses on <strong><?php echo date_format(new DateTime($dt),'l, F d, Y @ H:i:s'); ?>
						</strong> for <em style="color:Tomato;"><?php echo $in?></em></h5>
				

						
					<tbody>
							
							<tr>
								<th scope="row">Fever</th>
								<td><?php echo $fv; ?></td>
							</tr>
							<tr>
								<th scope="row">Cough</th>
								<td><?php echo $cg; ?></td>
							</tr>
							<tr>
								<th scope="row">Shortness of Breath / Difficulty Breathing</th>
								<td><?php echo $sh; ?></td>
							</tr>
							<tr>
								<th scope="row">Sore Throat</th>
								<td><?php echo $sr; ?></td>
							</tr>
							<tr>
								<th scope="row">Chills</th>
								<td><?php echo $ch; ?></td>
							</tr>
							
					</tbody>				
					
					
					
				</table>
			</div>
		
		


	<br> 
<br>

	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>


	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	

</body>
</html> 
	