<?php 

session_start();
	include('inc/healthcheck.php');


?>


<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | Password Reset</title>
		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
			crossorigin="anonymous">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
			crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
		
			
	</style>
	
</head>
<body>


<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="login.php" class="navbar-brand">Log In</a>
	  <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2">
            <a href="createuser.php" class="nav-link active">Create New Account</a>
          </li>
          <li class="nav-item px-2">
            <a href="passwordreset.php" class="nav-link">Reset Your Password</a>
          </li>
		</ul>
      </div>
    </div>
  </nav>
		
	
	<!-- HEADER -->
  <header id="main-header" class="py-2 bg-black text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h3>
            <i class="fas fa-unlock-alt"></i> Password Reset</h3>
        </div>
      </div>
    </div>
  </header>

<br>
		

<div class="container" align="left">
	<div class="card card-container">
		<form action="passwordreset.php" method="post" >

			<div class="form-row">
                <div class="col">
					<label><strong>Email Address:</strong></label> <br>
					<input type="text" name="email" placeholder="Enter a valid email address"/>
                </div>
                <div class="col">
					<label><strong>New Password:</strong></label> <br>
					<input type="password" name="password" placeholder="Enter your password"/>
                </div>
				<div class="col">
					<label><strong>Confirm Password:</strong></label> <br>
					<input type="password" name="confirmpassword" placeholder="Confirm your password"/>
                </div>
            </div>
			<br>			
			<button class="btn btn-lg btn-primary btn-block btn-signin"  name="reset" type="submit">Reset</button>
		</form>
	</div>
 </div>	




	<?php 
	
	if(isset($_POST['reset'])){
		$email = mysqli_real_escape_string($con,$_POST['email']);
		$password = mysqli_real_escape_string($con,$_POST['password']);
		$confirmpassword = $_POST['confirmpassword'];
		
		
		if($email=='' OR $password=='' OR $confirmpassword==''){
			echo "<script>alert('Please fill all the fields!')</script>";
			exit();
		}
		
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			echo "<script>alert('Your email is not valid!')</script>";
			exit();
		}
		
		$sel_email = "select * from users where email='$email'";
		$run_email = mysqli_query($con,$sel_email);
		
		$check_email = mysqli_num_rows($run_email);
		
		if($check_email==0){
			echo "<script>alert('This email does not exist!')</script>";
			exit();
		}
		
		
		if(strlen($password)<7){
			echo "<script>alert('Please select a password of 7 characters minimum!')</script>";
			exit();
		}
		
		
		if($password <> $confirmpassword){
			echo "<script>alert('Password input is not the same!')</script>";
			exit();
		}
		
		
		else{
			
			$password = md5($password); //---
			
			$update = "update users set password = '$password', modifydate = NOW() where email='$email'";
			
			$run_update = mysqli_query($con,$update);
			
			if($run_update){
				echo "<script>alert('Password reset successfully done...')</script>";
				echo "<script>window.open('login.php','_self')</script>";
			}
		}
		
		
	}
	
	?>


	<br> 
<br>

	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>


	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	

</body>
</html> 
	