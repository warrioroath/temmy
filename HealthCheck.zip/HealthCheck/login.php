<?php 

session_start();
	include('inc/healthcheck.php');
?>

<!DOCTYPE html>

<html>
<head>
		<title>LagoLindo | Login Panel</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<!-- Comment here -->
		<link rel="stylesheet" href="css/style.css" media="all"/>
		
		<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
	</style>
	

</head>

<body>

	<header id="main-header">
		<h1>Lago Lindo Day Care</h1>
	</header>


<hr>


		<div class="container" align='center'>
			<h4>Welcome to the Lago Lindo Health Check!</h4>
		</div>

	
	<div class="container">
        <div class="card card-container">

			<form action="login.php" method="post" class="form-signin" enctype="multipart/form-data">
				
				<h2 align="center"><strong>Member Login ...</strong></h2>
			
				<input type="text" name="username" class="form-control" placeholder="Enter Your Username" required autofocus/>
				<br>
				<input type="password" name="password" class="form-control" placeholder="Enter Your Password" required="required"/>
				
				<button class="btn btn-lg btn-primary btn-block btn-signin" name="login" type="submit">Log in</button>

			</form><!-- /form -->


		</div><!-- /card-container -->
	</div><!-- /container -->
	
	<div class="container" align='center'>
		<a href="createuser.php"><h4>Create new account</h4></a>
		<a href="passwordreset.php"><h4>Reset your password</h4></a>  
	</div><!-- /container -->
	
	
	
	
	
		
	<?php 
	
	if(isset($_POST['login'])){
		
		//getting the text information and saving in local variables
		$username = mysqli_real_escape_string($con,$_POST['username']);
		$password = mysqli_real_escape_string($con,$_POST['password']);
		
		$password = md5($password);
				
		$sel = "select * from users where username='$username' AND password='$password' AND verified = 1";
		//$sel = "select * from users where username='$username'";
		
		$run = mysqli_query($con,$sel);
		
		$check = mysqli_num_rows($run);
		
		/* if(password_verify($password1,$password)) {
			echo "Successful login";
		} else {
			echo "Bad password";
		}		 */
		
		/* NOTE:
		$password1 = user input on the form...
		$password = saved input in the DB... */
		
		if($check==0){
			echo "<script>alert('Password or Username is not correct, or your Account has not been verified. Try again!')</script>";
			exit();
		}
		else{
			$_SESSION['username']=$username;			
			echo "<script>window.open('index.php','_self')</script>";
		}
	
	}
		
	?>
	
	
	<br>
	<hr>
	
	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	
	
</body>
</html>


