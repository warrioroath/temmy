-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2021 at 06:03 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcheck`
--

-- --------------------------------------------------------

--
-- Table structure for table `checks`
--

CREATE TABLE `checks` (
  `id` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `individualname` varchar(255) NOT NULL,
  `todaydate` date NOT NULL,
  `fever` text NOT NULL,
  `cough` text NOT NULL,
  `shortness` text NOT NULL,
  `sore` text NOT NULL,
  `chills` text NOT NULL,
  `checkdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checks`
--

INSERT INTO `checks` (`id`, `username`, `individualname`, `todaydate`, `fever`, `cough`, `shortness`, `sore`, `chills`, `checkdate`) VALUES
(1, 'ipeola', 'Jordan Borle', '2020-10-10', 'No', 'No', 'No', 'No', 'No', '2020-10-10 01:13:48'),
(2, 'ipeola', 'Daniel Settle', '2020-10-10', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-10 20:01:45'),
(3, 'ayoomo', 'Patrick Henry', '2020-10-12', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-11 22:09:50'),
(4, 'ayoomo', 'John Mas', '2020-10-12', 'No', 'No', 'No', 'No', 'No', '2020-10-12 17:11:46'),
(5, 'ayoomo', 'Charles Doyle', '2020-10-12', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-12 17:15:21'),
(6, 'ayoomo', 'Patrick Henry', '2020-10-12', 'No', 'No', 'No', 'No', 'No', '2020-10-12 17:16:14'),
(7, 'ayoomo', 'Daniel Settle', '2020-10-12', 'No', 'No', 'No', 'No', 'No', '2020-10-12 17:20:30'),
(8, 'ipeola', 'Charles Doyle', '2020-10-14', 'No', 'No', 'No', 'No', 'No', '2020-10-13 22:31:27'),
(9, 'ipeola', 'Daniel Settle', '2020-10-14', 'No', 'No', 'Yes', 'No', 'No', '2020-10-13 23:13:29'),
(10, 'ipeola', '', '2020-10-14', 'Yes', 'Yes', 'No', 'No', 'Yes', '2020-10-13 23:15:36'),
(11, 'ayoomo', 'John Mas', '2020-11-04', 'No', 'Yes', 'No', 'Yes', 'No', '2020-11-04 20:24:26'),
(12, 'ayoomo', 'Daniel Settle', '2020-11-21', 'No', 'No', 'No', 'No', 'No', '2020-11-21 12:31:21'),
(13, 'ayoomo', '', '2020-12-03', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-12-03 00:34:56'),
(14, 'ayoomo', 'Charles Doyle', '2020-12-03', 'No', 'Yes', 'No', 'Yes', 'No', '2020-12-03 00:37:56'),
(15, 'ayoomo', 'Jordan Borle', '2020-12-03', 'No', 'Yes', 'No', 'Yes', 'No', '2020-12-03 00:38:51'),
(16, 'ipeola', 'Patrick Henry', '2020-12-03', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-12-03 00:46:52'),
(44, 'ayoomo', '', '2020-12-24', '', '', '', '', '', '2020-12-24 19:23:42'),
(47, 'ayoomo', '', '2020-12-24', 'Yes', '', 'No', '', 'Yes', '2020-12-24 19:55:33'),
(48, 'ayoomo', 'Jordan Borle', '2020-12-24', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-12-24 20:03:01'),
(49, 'ayoomo', '', '2020-12-24', 'Yes', 'Yes', 'No', 'No', 'Yes', '2020-12-24 20:41:07'),
(50, 'ayoomo', 'John Mas', '2020-12-25', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-12-25 07:50:52'),
(51, 'ipeola', 'Patrick Henry', '2020-12-30', 'No', 'Yes', 'No', 'Yes', 'No', '2020-12-30 01:05:33'),
(52, 'ipeola', 'John Mas', '2020-12-30', 'No', 'No', 'Yes', 'No', 'No', '2020-12-30 16:26:37'),
(53, 'opeale', 'Jordan Borle', '2021-01-02', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2021-01-02 12:08:45'),
(56, 'ipeola', 'Patrick Henry', '2021-01-12', 'Yes', '', '', 'No', 'Yes', '2021-01-12 04:43:59'),
(57, 'ipeola', 'John Mas', '2021-01-12', 'Yes', 'Yes', '', '', 'Yes', '2021-01-12 04:49:03'),
(58, 'ipeola', 'Charles Doyle', '2021-01-12', '', '', 'Yes', 'Yes', 'Yes', '2021-01-12 04:49:35'),
(59, 'adeayo', 'Jordan Borle', '2021-01-12', '', '', '', '', 'Yes', '2021-01-12 16:20:55'),
(60, 'adeayo', 'Daniel Settle', '2021-01-12', 'Yes', 'Yes', 'Yes', 'Yes', 'No', '2021-01-12 16:22:03'),
(73, 'adeayo', 'Jordan Borle', '2021-01-12', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2021-01-12 17:04:43'),
(74, 'adeayo', 'Daniel Settle', '2021-01-12', 'No', 'No', 'Yes', 'Yes', 'Yes', '2021-01-12 17:34:36'),
(75, 'ipeola', 'Charles Doyle', '2021-01-13', 'No', 'No', 'No', 'No', 'No', '2021-01-13 22:19:00'),
(76, 'ipeola', 'Patrick Henry', '2021-01-13', 'No', 'Yes', 'No', 'Yes', 'No', '2021-01-13 22:21:30'),
(77, 'ayoomo', 'John Mas', '2021-01-13', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2021-01-13 22:25:50'),
(78, 'oluwajenyo', 'Jordan Borle', '2021-01-14', 'No', 'No', 'No', 'No', 'No', '2021-01-14 05:48:14'),
(79, 'ayobami', 'Daniel Settle', '2021-01-14', 'Yes', 'No', 'Yes', 'No', 'Yes', '2021-01-14 21:28:36'),
(80, 'ayobami', 'Patrick Henry', '2021-01-14', 'No', 'No', 'No', 'No', 'No', '2021-01-14 21:33:49');

-- --------------------------------------------------------

--
-- Table structure for table `checks_cp`
--

CREATE TABLE `checks_cp` (
  `id` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `individualname` varchar(255) NOT NULL,
  `todaydate` date NOT NULL,
  `fever` text NOT NULL,
  `cough` text NOT NULL,
  `shortness` text NOT NULL,
  `sore` text NOT NULL,
  `chills` text NOT NULL,
  `checkdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checks_cp`
--

INSERT INTO `checks_cp` (`id`, `username`, `individualname`, `todaydate`, `fever`, `cough`, `shortness`, `sore`, `chills`, `checkdate`) VALUES
(1, 'ayoomo', 'Jordan Borle', '2020-09-18', 'No', 'No', 'No', 'No', 'No', '2020-09-18 21:13:10'),
(2, 'ipeola', 'Daniel Settle', '2020-09-18', 'No', 'No', 'No', 'No', 'No', '2020-09-18 21:24:13'),
(3, 'ipeola', 'Daniel Settle', '2020-09-20', 'No', 'No', 'No', 'No', 'No', '2020-09-19 22:14:40'),
(4, 'ipeola', 'Jordan Borle', '2020-09-20', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-09-19 22:16:51'),
(5, 'ipeola', 'Jordan Borle', '2020-09-20', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-09-19 22:17:09'),
(6, 'ipeola', 'Patrick Henry', '2020-09-20', 'No', 'No', 'No', 'No', 'No', '2020-09-19 22:17:25'),
(7, 'ipeola', 'Jordan Borle', '2020-09-20', 'No', 'No', 'No', 'No', 'No', '2020-09-19 22:22:05'),
(8, 'ayoomo', 'Daniel Settle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-20 23:22:37'),
(9, 'ipeola', 'Jordan Borle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 00:30:02'),
(10, 'ipeola', 'Jordan Borle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 00:30:13'),
(11, 'ipeola', 'Jordan Borle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 00:37:21'),
(12, 'ayoomo', 'Daniel Settle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 00:38:58'),
(13, 'ipeola', 'Jordan Borle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 01:44:30'),
(14, 'ayoomo', 'Patrick Henry', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 01:57:50'),
(15, 'ayoomo', 'Daniel Settle', '2020-09-21', 'No', 'No', 'No', 'No', 'No', '2020-09-21 05:47:24'),
(16, 'ipeola', 'John Mas', '2020-09-29', 'No', 'No', 'No', 'No', 'No', '2020-09-29 21:48:32'),
(17, 'ipeola', 'Patrick Henry', '2020-09-30', 'No', 'No', 'No', 'No', 'No', '2020-09-29 22:00:49'),
(18, 'ayoomo', 'Patrick Henry', '2020-09-30', 'No', 'No', 'No', 'No', 'No', '2020-09-29 23:09:09'),
(19, 'ayoomo', 'John Mas', '2020-10-07', 'No', 'No', 'No', 'No', 'No', '2020-10-07 01:00:55'),
(20, 'ipeola', 'Patrick Henry', '2020-10-07', 'No', 'No', 'No', 'No', 'No', '2020-10-07 05:29:48'),
(21, 'ayoomo', 'Daniel Settle', '2020-10-08', 'No', 'No', 'No', 'No', 'No', '2020-10-07 23:42:04'),
(22, 'ipeola', 'John Mas', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-07 23:46:18'),
(23, 'ipeola', 'Charles Doyle', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-07 23:47:03'),
(24, 'ipeola', 'Jordan Borle', '2020-10-08', 'No', 'Yes', 'No', 'Yes', 'No', '2020-10-07 23:49:20'),
(25, 'ipeola', 'Patrick Henry', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:03:10'),
(26, 'ipeola', 'John Mas', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:17:20'),
(27, 'ipeola', 'Charles Doyle', '2020-10-08', 'No', 'Yes', 'No', 'Yes', 'No', '2020-10-08 00:19:43'),
(28, 'ipeola', 'Daniel Settle', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:26:22'),
(29, 'ipeola', 'Charles Doyle', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:28:08'),
(30, 'ipeola', 'Patrick Henry', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:30:00'),
(31, 'ayoomo', 'Jordan Borle', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:42:05'),
(32, 'ayoomo', 'Daniel Settle', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:42:31'),
(33, 'ayoomo', 'Patrick Henry', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:43:17'),
(34, 'ayoomo', 'John Mas', '2020-10-08', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-08 00:44:37'),
(35, 'ayoomo', 'Patrick Henry', '2020-10-08', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-08 01:10:29'),
(36, 'ipeola', 'Charles Doyle', '2020-10-08', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-08 01:11:24'),
(37, 'ipeola', 'Jordan Borle', '2020-10-08', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-08 01:16:03'),
(38, 'ipeola', 'Daniel Settle', '2020-10-08', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-08 01:24:20'),
(39, 'ipeola', 'Jordan Borle', '2020-10-09', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-09 14:58:56'),
(40, 'ipeola', 'Jordan Borle', '2020-10-09', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-09 17:28:56'),
(41, 'ipeola', 'Jordan Borle', '2020-10-09', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-09 17:29:42'),
(42, 'ipeola', 'John Mas', '2020-10-09', 'Yes', 'No', 'Yes', 'Yes', 'No', '2020-10-09 19:58:01'),
(43, 'ayoomo', 'Patrick Henry', '2020-10-09', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '2020-10-09 20:02:42'),
(44, 'ipeola', 'John Mas', '2020-10-09', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-09 20:08:30'),
(45, 'ayoomo', 'Jordan Borle', '2020-10-09', 'Yes', 'No', 'Yes', 'No', 'Yes', '2020-10-09 20:10:28'),
(46, 'ipeola', 'Jordan Borle', '2020-10-09', 'Yes', 'No', 'No', 'Yes', 'No', '2020-10-09 20:11:53'),
(47, 'ipeola', 'Jordan Borle', '2020-10-09', 'Yes', 'Yes', 'No', 'Yes', 'Yes', '2020-10-09 20:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(100) NOT NULL,
  `questname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `questname`) VALUES
(1, 'Fever'),
(2, 'Cough'),
(3, 'Shortness of Breath / Difficulty Breathing'),
(4, 'Sore Throat'),
(5, 'Chills');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `vkey` varchar(355) NOT NULL,
  `verified` int(1) NOT NULL DEFAULT '0',
  `registerdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifydate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `vkey`, `verified`, `registerdate`, `modifydate`) VALUES
(1, 'ayo.omo@lindo.com', 'ayoomo', 'heal123', '', 0, '2020-12-30 19:29:09', '2021-01-02 11:58:30'),
(2, 'ipe.ola@lindo.com', 'ipeola', 'save123', '', 0, '2020-12-30 19:29:09', '2021-01-02 11:58:30'),
(3, 'ade.ayo@lingo.com', 'adeayo', 'look123', '', 0, '2020-12-30 19:51:49', '2021-01-02 11:58:30'),
(4, 'olu.omo@lingo.com', 'oluomo', 'true123', '', 0, '2020-12-30 20:18:12', '2021-01-02 11:58:30'),
(5, 'ope.ale@lingo.com', 'opeale', 'talk123', '', 0, '2021-01-02 12:04:03', '2021-01-02 12:05:12'),
(6, 'warrioroath@gmail.com', 'ayobami', '16d7a4fca7442dda3ad93c9a726597e4', '6987bea50f7e76003e36e55bf24f3a65', 0, '2021-01-13 19:57:19', '2021-01-13 19:57:19'),
(8, 'warrioroath@yahoo.com', 'oluwajenyo', 'f889709b75a5bbc49a3c05281dfe0eee', '198bd86a29a0f6687a90d08b390acaa6', 0, '2021-01-15 01:03:26', '2021-01-15 01:03:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checks`
--
ALTER TABLE `checks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checks_cp`
--
ALTER TABLE `checks_cp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checks`
--
ALTER TABLE `checks`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `checks_cp`
--
ALTER TABLE `checks_cp`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
