<?php 

	include('inc/healthcheck.php');
	
		$msg = "";
	
	if(isset($_POST['create'])){
		$email = mysqli_real_escape_string($con,$_POST['email']);
		$username = mysqli_real_escape_string($con,$_POST['username']);
		$password = mysqli_real_escape_string($con,$_POST['password']);
		$confirmpassword = $_POST['confirmpassword'];
		
		
		
		if($email=="" || $username=="" || $password==""){
			$msg = "Please fill all the fields!";
    		}elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
    			$msg = "Your email is not valid!";
        		} else {
        		    $sel_email = "SELECT id FROM users WHERE email regexp '$email'";
        		    $run_email = mysqli_query($con,$sel_email);
        		    $check_email = mysqli_num_rows($run_email);
        		    if($check_email >= 1){
        		    	$msg = "This email is already registered. Try another one!";
            	    	} else {
            	    	    $sel_username = "SELECT id FROM users WHERE username regexp '$username'";
                    		$run_username = mysqli_query($con,$sel_username);
                    		$check_username = mysqli_num_rows($run_username);
                    		
                    		if($check_username>=1){
                    			$msg = "This username is already registered. Try another one!";
                    		} else {
                    		   if(strlen($password)<7){
                        			$msg = "Please select a password of 7 characters minimum!'";
                        		} else {
                        		    if($password <> $confirmpassword){
                            			$msg = "Your passwords do not match!";
                            		}else{
                            		   
		    //Process valid details
		    $password = md5($password);
			
			
			//Generate Verification Key
			$vkey = md5(time().$username);
			
			
			$insert = "INSERT INTO users (email,username,password,vkey,registerdate,modifydate) VALUES ('$email','$username','$password','$vkey',NOW(),NOW())";
			
			$run_insert = mysqli_query($con,$insert);
			
			if($run_insert){
				$msg = "New account successfully created... Welcome!";
				
				//Send email
				
				$to = $email;
				
				$subject = "Email Verification - Health Check";
				
				$message = '<p>Kindly click on the link below to verify your account:</p><br/>';
				$message .= "<a href='https://fulfilmentpriority.com/HealthCheck/verify.php?username=$username&vkey=$vkey'>Verify to Register your Account</a>";
				$message .= '<br/>Or, copy and paste it in a browser, then press Enter.<br/>';
				$message .= '<br/><p>Thank you.</p><br/>';
				
				$headers = "From: " . "Ayobami Oluwajenyo <ayobami@fulfilmentpriority.com> " . "\r\n";
				$headers .= "Reply-To:" . "ayobami@fulfilmentpriority.com" . "\r\n" ."X-Mailer: PHP/" . phpversion();
				$headers .= "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				mail($to,$subject,$message,$headers);
				
				header('location:thankyoumessage.php');
    				
    			}else{
        				echo $mysqli->error;
        				//echo "<script>window.open('login.php','_self')</script>";
        			}
                		}
            		}
        		}
	    	}
	    	
		} 
	
		
			echo "<script>alert('$msg')</script>";
			
		}
		

?>


<!DOCTYPE html>
<html>
<head>
	<title>LagoLindo | New Account</title>
		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
			crossorigin="anonymous">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
			crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		
		
	<style type="text/css">
		#main-header{
			text-align:center;
			background-color:black;
			color:white;
			padding:10px;
		}

		#main-footer{
			text-align: center;
			font-size:18px;
		}
		
			
	</style>
	
</head>
<body>
    
    
  


<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="login.php" class="navbar-brand">Log In</a>
	  <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2">
            <a href="createuser.php" class="nav-link active">Create New Account</a>
          </li>
          <li class="nav-item px-2">
            <a href="passwordreset.php" class="nav-link">Reset Your Password</a>
          </li>
		</ul>
      </div>
    </div>
  </nav>
		
	
	<!-- HEADER -->
  <header id="main-header" class="py-2 bg-black text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h3>
            <i class="far fa-user-circle"></i> Create New Account</h3>
        </div>
      </div>
    </div>
  </header>

<br>




<div class="container" align="left">
	<div class="card card-container">
		<form action="createuser.php" method="post" >

			<div class="form-row">
                <div class="col">
					<label><strong>Email Address:</strong></label> <br>
					<input type="text" name="email" placeholder="Enter a valid email address"/>
                </div>
                <div class="col">
					<label><strong>Username:</strong></label> <br>
					<input type="text" name="username" placeholder="Enter a username"/>
                </div>
				<div class="col">
					<label><strong>Password:</strong></label> <br>
					<input type="password" name="password" placeholder="Enter your password"/>
                </div>
				<div class="col">
					<label><strong>Confirm Password:</strong></label> <br>
					<input type="password" name="confirmpassword" placeholder="Confirm your password"/>
                </div>
            </div>
			<br>			
			<button class="btn btn-lg btn-primary btn-block btn-signin"  name="create" type="submit">Create New Account</button>
		</form>
	</div>
 </div>	




  
    <?php 
	



	
	?>
    


	

<br> 
<br>


	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  	<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>


	<footer id="main-footer">
		<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script>, Ayobami Oluwajenyo Solutions.</p>
	</footer>
	

</body>
</html> 
